import { fetchFromTMDB } from "../services/tmdb.services.js";

export async function getTrendingTv(req, res) {
    try {
        const data = await fetchFromTMDB("https://api.themoviedb.org/3/trending/tv/day?language=en-US");
        const randomTv = data.results[Math.floor(Math.random() * data.results?.length)];

        res.json({ success: true, content: randomTv });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error in the TV controller" });
    }
}

export async function getTvTrailers(req, res) {
    const { id } = req.params;
    try {
        const data = await fetchFromTMDB(`https://api.themoviedb.org/3/tv/${id}/videos?language=en-US`);
        res.json({ success: true, trailer: data.results });

    } catch (error) {
        if(error.message.include("404")){
            return res.status(404).send(null);
        }
        res.status(500).json({success:false,message:"Error in the TV trailer Controller System"});

    }

}

export async function getTvDetails(req,res) {
    const {id} =req.params;
    try{
        const data =await fetchFromTMDB(`https://api.themoviedb.org/3/tv/${id}?language=en-US`);
        res.json({ success: true, content: data });

    }catch(error){
        if(error.message.include("404")){
            return res.status(404).send(null);
        }
        res.status(500).json({success:false,message:"Error in the TV Details Controller System"});

    }
    
}

export async function getSimilarTvs(req,res) {
    const {id}=req.params;
    try{
        const data = await fetchFromTMDB(`https://api.themoviedb.org/3/tv/${id}/similar?language=en-US&page=1`);
        res.status(200).json({success:true,message:"data.results"});

    }catch(error){
        res.status(500).json({success:false,message:"Error in Similar TV Controllers"});
    }
    
}

export async function getTvsByCategory(req,res) {
    const {id} = req.params;
    try{
        const data =await fetchFromTMDB(`https://api.themoviedb.org/3/tv/${category}?language=en-US&page=1`);
        res.status(200).json({success:true,message:"data.results"});
    }
    catch(error){
        res.status(500).json({success:false,message:"Error in  TV By Category Controllers"});
    }

    
}